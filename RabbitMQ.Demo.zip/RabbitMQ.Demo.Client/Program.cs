﻿// See https://aka.ms/new-console-template for more information


Console.WriteLine("消费者-服务已开始启动 ......");

new RabbitMQDataServices().ReceivedMQData();


bool b = true;
while (b)
{
    if (Console.ReadLine().ToLower() == "exit") { b = false; }
    Thread.Sleep(1000);
}
