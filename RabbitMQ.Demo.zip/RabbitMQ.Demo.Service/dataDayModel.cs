﻿namespace RabbitMQ.Demo;

public record dataDayModel(string deviceId,string deviceName);

